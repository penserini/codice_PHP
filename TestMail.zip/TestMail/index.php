<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\Exception;

        /* Classe per gestire le eccezioni*/
        require 'C:\xampp\htdocs\TestMail\PHPMailer-master\src\Exception.php';
        
        /* Classe principale di PHPMailer */
        require 'C:\xampp\htdocs\TestMail\PHPMailer-master\src\PHPMailer.php';

        /* Classe del servizio SMTP, necessaria per poter inviare le e-mail tramite SMTP. */
        require 'C:\xampp\htdocs\TestMail\PHPMailer-master\src\SMTP.php';
        
        $destinatario = 'penseloris@gmail.com';
        $oggetto = 'test mail x ITS Magento';
        $messaggio = "Esempio di messaggio per la mail.\r\nSaluti,\r\nProf. ...";
        //$messaggio = wordwrap($messaggio, 70, "\r\n");
        
        $mail = new PHPMailer();
        $mail->SMTPDebug = 2;
        $mail->IsSMTP(); // Utilizzo della classe SMTP al posto del comando php mail()
        $mail->IsHTML(true);
        $mail->SMTPAuth = true; // Autenticazione SMTP
        //$mail->Host = "smtp.gmail.com";
        //$mail->Host = 'smtp.gmail.com;smtp1.gmail.com';
        $mail->Host = 'tls://smtp.gmail.com';
        $mail->Port = 587;//465 e 587
        $mail->SMTPSecure = 'tls';//ssl e tls
        $mail->Username = 'xxx'; // Nome utente SMTP autenticato: penseloris@gmail.com
        $mail->Password = 'xxx'; // Password account email con SMTP autenticato
        $mail->Priority    = 1; // Highest priority - Email priority (1 = High, 3 = Normal, 5 = low)
        
        $mail->setFrom = "penseloris@gmail.com";
        $mail->FromName = "Test - Prof";
        //$mail->AddAddress($email);
        $mail->AddAddress($destinatario,'elpense@gmail.com');
        
        $mail->Subject  =  $oggetto;
        $mail->Body     =  $messaggio;
        $mail->AltBody  =  "";
        //$mail->AddAttachment($path_allegato); 
        if(!$mail->Send()){
                echo "errore nell'invio della mail: ".$mail->ErrorInfo;
                return false;
        }else{
                echo "MAIL INVIATA CON SUCCESSO!!";
                return true;
        }
        
        ?>
    </body>
</html>
